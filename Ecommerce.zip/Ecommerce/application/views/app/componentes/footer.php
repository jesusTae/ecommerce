  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo base_url('asset/app/js/popper.min.js')?>"></script>
    <script src="<?php echo base_url('asset/app/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('asset/administrativo/js/alertify.js');?>"></script>	
    <script src="<?php echo base_url('asset/administrativo/js/datatables.min.js');?>"></script>
	
  </body>
</html>