
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Dashio</strong>. All Rights Reserved
        </p>
        <div class="credits">
         
          Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
        </div>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?php echo base_url('asset/administrativo/lib/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo base_url('asset/administrativo/lib/jquery-ui-1.9.2.custom.min.js')?>"></script>
  <script src="<?php echo base_url('asset/administrativo/lib/jquery.ui.touch-punch.min.js')?>"></script>
  <script class="include" type="text/javascript" src="<?php echo base_url('asset/administrativo/lib/jquery.dcjqaccordion.2.7.js')?>"></script>
  <script src="<?php echo base_url('asset/administrativo/lib/jquery.scrollTo.min.js')?>"></script>
  <script src="<?php echo base_url('asset/administrativo/lib/jquery.nicescroll.js')?>" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="<?php echo base_url('asset/administrativo/lib/common-scripts.js')?> "></script>
  <script src="<?php echo base_url('asset/administrativo/js/datatables.min.js');?>"></script>
  <script src="<?php echo base_url('asset/administrativo/js/alertify.js');?>"></script>	
  <script src="<?php echo base_url('asset/administrativo/lib/bootstrap-fileupload/bootstrap-fileupload.js');?>"></script>	
  <script src="<?php echo base_url('asset/administrativo/js/fileinput.min.js');?>"></script>	

  <!--script for this page-->
</body>

</html>
